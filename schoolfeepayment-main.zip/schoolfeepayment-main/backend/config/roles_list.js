const ROLES_LIST = {
    'Admin': 5150,
    "Owner": 2001
}

module.exports = ROLES_LIST