import { useRef, useEffect } from "react";
import { useDispatch } from "react-redux";

const usePaymentBase = () => {
  return (  
    <div>usePaymentBase</div>
  )
}

export default usePaymentBase