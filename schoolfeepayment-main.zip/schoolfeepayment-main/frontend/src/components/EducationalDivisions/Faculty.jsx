import React from 'react'

const Faculty = () => {
  return (
    <div>Faculty</div>
  )
}

export default Faculty