import React from 'react'

const Stages = () => {
  return (
    <div>Stages</div>
  )
}

export default Stages