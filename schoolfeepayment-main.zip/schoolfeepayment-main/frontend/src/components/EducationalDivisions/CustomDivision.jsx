import React from 'react'

const CustomDivision = () => {
  return (
    <div>CustomDivision</div>
  )
}

export default CustomDivision