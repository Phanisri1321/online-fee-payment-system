import React from "react";

const DynamicFunctions = () => {
  return <></>;
};

export default DynamicFunctions;
