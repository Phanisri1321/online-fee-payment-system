import "../../../Styles/signInBtnStyle.css"

const SignInButton = () => {
  return (
    <div className="btn-signin--container flex">
      <p>Sign In</p>
    </div>
  );
};

export default SignInButton;
