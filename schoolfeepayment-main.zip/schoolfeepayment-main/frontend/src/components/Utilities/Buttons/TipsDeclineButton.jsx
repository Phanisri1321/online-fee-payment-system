import '../../../Styles/tipsDeclineButtonStyle.css'

const TipsDeclineButton = ({ label }) => {
  return (
    <div className='tips-decline-btn--container flex-c'>{label}</div>
  )
}

export default TipsDeclineButton