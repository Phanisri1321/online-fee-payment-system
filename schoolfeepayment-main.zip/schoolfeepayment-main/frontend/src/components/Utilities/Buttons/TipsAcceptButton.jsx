import "../../../Styles/tipsAcceptButtonStyle.css";
const TipsAcceptButton = ({ label }) => {
  return <div className="tips-accept-btn--container flex">{label}</div>;
};

export default TipsAcceptButton;
