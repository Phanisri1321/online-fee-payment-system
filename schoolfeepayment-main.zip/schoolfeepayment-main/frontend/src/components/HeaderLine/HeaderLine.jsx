import "./headerLineStyles.css";

const HeaderLine = (props) => {
  return <div className="header-line"></div>;
};

export default HeaderLine;
